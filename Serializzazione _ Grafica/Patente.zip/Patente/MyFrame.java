import javax.swing.*;

public class MyFrame extends JFrame{
	public MyFrame(String titolo) {
		super(titolo);
		setSize(900,600);
	}
}
